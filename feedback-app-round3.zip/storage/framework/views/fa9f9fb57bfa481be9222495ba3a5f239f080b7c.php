<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    <style>
        .setting-icon-container {
            /* height: 25px; */
            height: 100%;
            width: 100%;
            /* display: flex;
            justify-content: flex-end; */
            padding: 1px;
        }

        .hide {
            visibility: hidden;
        }

        .setting-icon-container:hover {
            color: black;
        }

        .setting-icon-container:hover {
            background-color: rgba(84, 108, 108, 0.19);
        }

        .setting-icon-container:hover .hide {
            visibility: visible;
        }
    </style>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class=" container  py-1 d-flex bg-light justify-content-between ">
                <div class="fs-4 fw-bold">
                    Companies
                </div>
                <div class="pt-1">
                    <!-- Button trigger modal for add Company -->
                    <button class="shadow ml-1 px-2 rounded" data-bs-toggle="modal" data-bs-target="#exampleModal">
                        <span>
                            Add
                        </span>
                    </button>
                    <!-- Go to restore company -->
                    <button class="bg-info shadow ml-1 px-2 rounded">
                        <a href="/company/restore" class="text-decoration-none text-dark">
                            Restore
                        </a>
                    </button>
                </div>
                <!-- Modal for Add Company -->
                <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                    <div class="modal-dialog modal-lg">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="exampleModalLabel">Add Company</h5>
                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                            </div>
                            <form action="/companies" method="POST" enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
                                <div class="modal-body">
                                    <div class="mb-3">
                                        <label for="exampleFormControlInput1" class="form-label">Company Name</label>
                                        <input type="text" class="form-control capitalized" id="exampleFormControlInput1" placeholder="Company Name" name="name" required>
                                    </div>
                                    <div class="mb-3">
                                        <label for="exampleFormControlInput1" class="form-label">About</label>
                                        <textarea rows="6" class="form-control capitalized" id="exampleFormControlInput1" name="about" required></textarea>
                                    </div>
                                    <div class="mb-3">
                                        <label for="exampleFormControlInput1" class="form-label">Company Type</label>
                                        <input type="text" class="form-control capitalized" id="exampleFormControlInput1" name="company_type" placeholder="Company Type" required>
                                    </div>
                                    <div class="mb-3">
                                        <label for="exampleFormControlInput1" class="form-label">Company Logo</label>
                                        <input type="file" accept="image/*" name="file" class="form-control edit-file" required />
                                    </div>
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                    <button type="submit" class="btn btn-primary">Save Company</button>
                                </div>

                            </form>
                        </div>
                    </div>
                </div>
            </div>
            <div class="container p-2 rounded d-flex bg-white justify-content-around justify-content-md-start">
                <?php $__currentLoopData = $companies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $company): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="card bg-light text-white col-lg-2 col-md-4 col-6 p-2 m-1">
                    <img src="<?php echo e(asset('images/company')); ?>/<?php echo e($company->image); ?>" alt="<?php echo e($company->name); ?>" class="card-img" alt="...">
                    <div class="card-img-overlay p-0 d-flex justify-content-end">
                        <div class="setting-icon-container">
                            <!-- <span class="material-icons">
                                settings
                            </span> -->

                            <a href="#" class="position-absolute top-0 end-0" role=" button" id="dropdownMenuLink" data-bs-toggle="dropdown" aria-expanded="false">
                                <span class="material-icons">
                                    settings
                                </span>

                            </a>

                            <div class="p-4">
                                <div class="col-12 mt-4 py-4 text-center fs-4">
                                    <a href="/companies/<?php echo e($company->id); ?>" class="hide bg-light p-1 rounded text-decoration-none">View</a>
                                </div>
                            </div>

                            <ul class="dropdown-menu" aria-labelledby="dropdownMenuLink">
                                <!-- For Admin buttons -->
                                <?php if(Auth::user()->id === 1): ?>
                                <!-- If Inactive -->
                                <?php if($company->status->id == 1): ?>
                                <form action="/companies/<?php echo e($company->id); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('PUT'); ?>
                                    <li>
                                        <button class="dropdown-item">
                                            Activate
                                        </button>
                                    </li>
                                </form>
                                <!-- if Active -->
                                <?php else: ?>
                                <form action="/companies/<?php echo e($company->id); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('PUT'); ?>
                                    <li>
                                        <button class="dropdown-item">
                                            Inactivate
                                        </button>
                                    </li>
                                </form>
                                <?php endif; ?>

                                <!-- for User -->
                                <?php else: ?>
                                <li>
                                    <!-- Button trigger to Edit modal -->
                                    <p class="dropdown-item" data-bs-toggle="modal" data-bs-toggle="modal" data-bs-target="#<?php echo e(str_replace(" ", "",$company->name).$company->id); ?>">Edit</p>
                                </li>
                                <form action="/companies/<?php echo e($company->id); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <li>
                                        <button class="dropdown-item">
                                            Delete
                                        </button>
                                    </li>
                                </form>
                                <?php endif; ?>
                            </ul>
                            <!-- Edit Modal -->
                            <div class="modal fade" id="<?php echo e(str_replace(" ", "",$company->name).$company->id); ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                <div class="modal-dialog modal-lg">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <h5 class="modal-title text-dark" id="exampleModalLabel">Edit Company</h5>
                                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                        </div>
                                        <form action="/companies/<?php echo e($company->id); ?>" method="POST" enctype="multipart/form-data">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('PUT'); ?>
                                            <div class="modal-body">
                                                <div class="mb-3">
                                                    <label for="exampleFormControlInput1" class="form-label">Company Name</label>
                                                    <input type="text" class="form-control capitalized" id="exampleFormControlInput1" placeholder="Company Name" name="name" required value="<?php echo e($company->name); ?>">
                                                </div>
                                                <div class="mb-3">
                                                    <label for="exampleFormControlInput1" class="form-label">About</label>
                                                    <textarea rows="6" class="form-control capitalized" id="exampleFormControlInput1" name="about" required value=><?php echo e($company->about); ?></textarea>
                                                </div>
                                                <div class="mb-3">
                                                    <label for="exampleFormControlInput1" class="form-label">Company Type</label>
                                                    <input type="text" class="form-control capitalized" id="exampleFormControlInput1" name="company_type" placeholder="Company Type" required value=<?php echo e($company->company_type); ?>>
                                                </div>
                                                <div class="mb-3">
                                                    <label for="exampleFormControlInput1" class="form-label">Company Logo</label>
                                                    <input type="file" accept="image/*" name="file" class="form-control edit-file" />
                                                </div>
                                            </div>
                                            <div class="modal-footer">
                                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                                <button type="submit" class="btn btn-primary">Save Company</button>
                                            </div>

                                        </form>

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="text-center">
                        <h5 class="card-title text-dark bg-light"><?php echo e($company->name); ?></h5>
                        <?php if($company->status->id == 1): ?>
                        <p class="card-text bg-danger"><?php echo e($company->status->name); ?></p>
                        <?php else: ?>
                        <p class="card-text bg-success"><?php echo e($company->status->name); ?></p>
                        <?php endif; ?>

                    </div>
                </div>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </div>
        </div>

    </div>



 <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?><?php /**PATH C:\Users\Paul\Desktop\feedback-app-round3\resources\views/company/company.blade.php ENDPATH**/ ?>