<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    <style>
        .setting-icon-container {
            height: 25px;
            padding: 1px;
        }

        .setting-icon-container:hover>span {
            color: red;
        }

        a {
            text-decoration: none;
            color: black;
        }
    </style>

    <div class="py-12">
        <!-- Trashed Companies -->

        <div class=" container  py-1 d-flex bg-light justify-content-between ">
            <div class="fs-4 fw-bold">
                Trashed
            </div>
        </div>
        <div class="container p-2 rounded d-flex bg-white justify-content-around justify-content-md-start">
            <!-- Empty Trash -->
            <?php if($trashedProducts->count() == 0): ?>
            <div class="alert alert-light" role="alert">
                <i class="fas fa-trash-alt"></i> Trash Empty!
            </div>
            <?php else: ?>
            <!-- Restored Success -->
            <?php if(session('message')): ?>
            <div class="alert alert-secondary" role="alert">
                Product Restored - <a href="/<?php echo e(session('message')); ?>">View Restored Product</a>
            </div>
            <?php endif; ?>
            <!-- Display All Products -->
            <?php $__currentLoopData = $trashedProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $trashedProduct): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="card bg-light text-white col-lg-2 col-md-4 col-6 p-2 m-1">
                <img src="<?php echo e(asset('images/product')); ?>/<?php echo e($trashedProduct->image); ?>" alt="<?php echo e($trashedProduct->name); ?>" class="card-img" alt="...">
                <div class="card-img-overlay p-0 d-flex justify-content-end">
                    <div class="setting-icon-container">
                        <!-- <span class="material-icons">
                                settings
                            </span> -->

                        <a href="#" role="button" id="dropdownMenuLink" data-bs-toggle="dropdown" aria-expanded="false">
                            <span class="material-icons">
                                settings
                            </span>

                        </a>

                        <ul class="dropdown-menu " aria-labelledby="dropdownMenuLink">
                            <li>
                                <form action="/product/restore/<?php echo e($trashedProduct->id); ?>" action="POST">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('PUT'); ?>
                                    <input type="hidden" name="product_id" value="<?php echo e($trashedProduct->id); ?>">
                                    <button class="dropdown-item">Restore</button>
                                </form>
                            </li>
                        </ul>
                    </div>
                </div>
                <div class="text-center">
                    <h5 class="card-title text-dark bg-light"><?php echo e($trashedProduct->name); ?></h5>
                    <p class=" card-text bg-danger"><?php echo e($trashedProduct->status->name); ?></p>
                </div>
            </div>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>

        </div>

    </div>

 <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?><?php /**PATH C:\Users\Paul\Desktop\feedback-app-round3\resources\views/product/restore.blade.php ENDPATH**/ ?>