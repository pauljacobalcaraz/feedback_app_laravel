<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>

    <div class="container bg-gray-50 p-4 text-center">
        <div class="container shadow overflow-hidden btn position-relative" style="max-height: 400px;" data-bs-toggle="modal" data-bs-target="#exampleModal">

            <img src="<?php echo e(asset('images/products')); ?>/<?php echo e($product->image); ?>" class="img-fluid rounded-start" alt="<?php echo e($product->image); ?>">
        </div>
    </div>
    <div class="container d-md-flex justify-content-between bg-light p-4 mt-4">
        <div class="col-md-4 mb-2">
            <div class="bg-gray-100 col-md-11 p-2 shadow">
                <div class="fs-4 fw-bold mb-2">
                    Company
                </div>
                <div class="d-flex">
                    <span class="align-top ml-2 col-2">
                        <img src="<?php echo e(asset('images/company')); ?>/<?php echo e($company->image); ?>" class="img-fluid rounded-start" alt="<?php echo e($company->image); ?>">
                    </span>
                    <span class="ml-2 align-bottom d-flex flex-column justify-content-center text-capitalize">
                        <b>
                            <a href="/companies/<?php echo e($company->id); ?>" class="text-decoration-none">
                                <?php echo e($company->name); ?>

                            </a>
                        </b>
                    </span>
                </div>
            </div>
        </div>

        <div class="col-md-8 container bg-gray-100 m-0 p-2 shadow">
            <div class="fs-4 fw-bold mb-2">
                Details
            </div>

            <div>
                <small class="align-top text-justify">
                    <b>
                        name:
                    </b>
                    <?php echo e($product->name); ?>

                </small>
            </div>
            <div>
                <small class="align-top text-justify">
                    <b>
                        Released Date:
                    </b>
                    <?php echo e($product->released_date); ?>

                </small>
            </div>
            <div>
                <small class="align-top text-justify">
                    <b>
                        Description:
                    </b><br>
                    <?php echo e($product->description); ?>

                </small>
            </div>
        </div>
    </div>


    <!-- Modal  fullscre img-->
    <div class="modal fade bg-dark" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content bg-transparent">
                <img src="<?php echo e(asset('images/products')); ?>/<?php echo e($product->image); ?>" class="img-fluid rounded-start" alt="<?php echo e($product->image); ?>">
            </div>
        </div>
    </div>
    <!--End of modal  fullscre img-->

    <!-- Feedbacks layout -->
    <div class="container bg-light p-4 mt-4">
        <div class="d-flex">
            <div class="fs-4 fw-bold mb-2 mr-2">
                Feedbacks
            </div>
            <p>
                <button class="btn btn-success" type="button" data-bs-toggle="collapse" data-bs-target="#collapseExample" aria-expanded="false" aria-controls="collapseExample">
                    Filter
                </button>
                <small>By Label: </small>
                <span class="badge bg-info p-1 m-0 text-dark">
                    <?php echo e($filtered_label); ?>

                </span>
            </p>
        </div>
        <div class="collapse" id="collapseExample">
            <div class=" card-body">
                <div>
                    <div class="form-check form-check-inline">
                        <form action="/filtered_feedback" method="POST">
                            <?php echo csrf_field(); ?>
                            <button class="btn shadow-sm" name="all_label" value="All">
                                All
                            </button>
                            <?php $__currentLoopData = $labels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <button class="btn shadow-sm" name="label_id" value="<?php echo e($label->id); ?>">
                                <?php echo e($label->name); ?>

                            </button>
                            <!-- Sesssion -->
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        <?php $__currentLoopData = $feedbacks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $feedback): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class=" shadow mb-3 col-12 mx-auto p-3">
            <div class="row g-0 border-bottom pb-4">

                <div class="col-md-2 d-flex flex-column justify-content-center">
                    <div class="col-9 bg-gray-200 mx-auto mb-2">
                        <p class="fs-2 text-center p-4"><?php echo e($feedback->votes->count()); ?></p>
                    </div>

                    <?php if($feedback->votes->pluck('email')->first() == Auth::user()->email): ?>
                    <div class=" col-9 text-center mx-auto mb-2">
                        <div class=" col-12 bg-info shadow p-2 fw-bold">
                            VOTED!
                        </div>
                    </div>
                    <?php else: ?>
                    <div class="col-9 text-center mx-auto">
                        <form action="/votes" method="POST">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="feedback_id" value="<?php echo e($feedback->id); ?>">
                            <button class="btn btn-light shadow col-12 fw-bold">
                                VOTE
                            </button>
                        </form>
                    </div>
                    <?php endif; ?>

                    <div class="col-11 px-3 text-center mx-auto fw-bold  mt-2">
                        <?php if($feedback->action->name === 'Proposed'): ?>
                        <p class="bg-info">
                            <?php echo e($feedback->action->name); ?>

                        </p>
                        <?php elseif($feedback->action->name === 'On Development'): ?>
                        <p class="bg-primary">
                            <?php echo e($feedback->action->name); ?>

                        </p>
                        <?php elseif($feedback->action->name === 'Updated'): ?>
                        <p class="bg-success">
                            <?php echo e($feedback->action->name); ?>

                        </p>
                        <?php endif; ?>
                    </div>

                </div>
                <div class="col-md-10">
                    <?php if($feedback->user_id == Auth::user()->id or Auth::user()->id == $feedback->product->user_id or $feedback->product->user_id == Auth::user()->id): ?>
                    <div class="container d-flex justify-content-end px-3 p-0">
                        <div class="dropdown">
                            <i class="fas fa-ellipsis-h pt-2 " type="button" id="dropdownMenuButton1" data-bs-toggle="dropdown" aria-expanded="false"></i>

                            <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton1">
                                <?php if($feedback->user_id == Auth::user()->id): ?>
                                <li>
                                    <p class="dropdown-item" data-bs-toggle="modal" data-bs-toggle="modal" data-bs-target="#<?php echo e(str_replace(" ", "",$feedback->title).$feedback->id); ?>">Edit</p>
                                </li>
                                <?php endif; ?>
                                <?php if($feedback->product->user_id == Auth::user()->id): ?>
                                <?php $__currentLoopData = $actions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $action): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li>
                                    <form action="/feedbacks/<?php echo e($feedback->id); ?>" method="POST" enctype="multipart/form-data">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('PUT'); ?>
                                        <button class="dropdown-item" name="action_id" value="<?php echo e($action->id); ?>"><?php echo e($action->name); ?></button>
                                    </form>
                                </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                                <li>
                                    <button class="dropdown-item" data-bs-toggle="modal" data-bs-toggle="modal" data-bs-target="#<?php echo e("delete".str_replace(" ", "",$feedback->title).$feedback->id); ?>">
                                        Delete
                                    </button>
                                </li>
                            </ul>
                            <!-- Delete Modal -->
                            <div class="modal fade" id="<?php echo e("delete".str_replace(" ", "",$feedback->title).$feedback->id); ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                <div class="modal-dialog modal-lg">
                                    <div class="modal-content">
                                        <div class="card-header">
                                            <h5 class="modal-title text-dark" id="exampleModalLabel">Delete Feedback?</h5>
                                        </div>
                                        <div class="card-body">
                                            <div class="card-body">
                                                <p class="m-0">
                                                    <b class="card-title fs-5">
                                                        <?php echo e($feedback->title); ?>

                                                    </b>
                                                    <small class=""> <?php echo e('@'.$feedback->user->name); ?></small>
                                                    <br>

                                                    <small class="text-muted"><?php echo e($feedback->updated_at->diffForHumans()); ?></small>
                                                </p>
                                            </div>
                                        </div>
                                        <div class="card-footer">

                                            <form action="/feedbacks/<?php echo e($feedback->id); ?>" method="POST">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <button class=" btn-danger btn float-end">
                                                    Delete
                                                </button>
                                            </form>

                                        </div>

                                    </div>
                                </div>
                            </div>
                            <!-- Edit Modal -->
                            <div class="modal fade" id="<?php echo e(str_replace(" ", "",$feedback->title).$feedback->id); ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                <div class="modal-dialog modal-lg">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <h5 class="modal-title text-dark" id="exampleModalLabel">Edit Feedback</h5>
                                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                        </div>
                                        <form action="/feedbacks/<?php echo e($feedback->id); ?>" method="POST" enctype="multipart/form-data">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('PUT'); ?>
                                            <div class="modal-body">
                                                <div class="mb-3">
                                                    <label for="exampleFormControlInput1" class="form-label">Title</label>
                                                    <input type="text" class="form-control capitalized" id="exampleFormControlInput1" placeholder="Title" name="title" required value="<?php echo e($feedback->title); ?>">
                                                </div>
                                                <?php $__currentLoopData = $labels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <div class="form-check form-check-inline">
                                                    <?php if($feedback->label_id == $label->id): ?>
                                                    <input class="form-check-input" type="radio" name="label_id" id="inlineRadio1" value="<?php echo e($label->id); ?>" required checked>
                                                    <label class="form-check-label" for="inlineRadio1"><?php echo e($label->name); ?></label>
                                                    <?php else: ?>
                                                    <input class="form-check-input" type="radio" name="label_id" id="inlineRadio1" value="<?php echo e($label->id); ?>" required>
                                                    <label class="form-check-label" for="inlineRadio1"><?php echo e($label->name); ?></label>
                                                    <?php endif; ?>
                                                </div>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <textarea class="form-control" id="exampleFormControlTextarea1" rows="10" name="feedback" required><?php echo e($feedback->feedback); ?></textarea>
                                            </div>
                                            <div class="modal-footer">
                                                <div class="d-flex justify-content-end mt-2">
                                                    <button class="btn shadow-sm btn-primary">Submit</button>
                                                </div>
                                            </div>

                                        </form>

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php endif; ?>
                    <span class="badge bg-info p-1 m-0 text-dark shadow">
                        <?php echo e($feedback->label->name); ?>

                    </span>
                    <div class="card-body">
                        <p class="m-0">
                            <b class="card-title fs-5">
                                <?php echo e($feedback->title); ?>

                            </b>
                            <small class=""> <?php echo e('@'.$feedback->user->name); ?></small>
                            <br>

                            <small class="text-muted"><?php echo e($feedback->updated_at->diffForHumans()); ?></small>
                        </p>
                        <p class="card-text py-3"><?php echo e($feedback->feedback); ?></p>
                    </div>
                </div>
            </div>


            <form action="/comments" method="POST"><br>
                <div class="container">
                    <small class="ml-3 fw-bold">Add Comment</small>
                </div>
                <div class="container col-12 d-md-flex mt-2">
                    <?php echo csrf_field(); ?>
                    <div class="form-floating col-md-7 ml-2">
                        <input type="hidden" value="<?php echo e($feedback->id); ?>" name="feedback_id">
                        <textarea class="form-control" name="comment" placeholder="Leave a comment here" id="floatingTextarea" rows="1" required></textarea>
                        <label for="floatingTextarea">Comment</label>
                    </div>
                    <div class="col-10 pt-3">
                        <button class="btn btn-info ml-3">Submit</button>
                    </div>
                </div>
            </form>

            <?php
            $filtered_comments = $comments->where('feedback_id', $feedback->id)
            ?>
            <div class="container">
                <div class="card col-12 border-0 mx-auto p-2 bg-transparent">
                    <?php $__currentLoopData = $filtered_comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="card mb-3 border-0 bg-white shadow">
                        <div class="row g-0">
                            <div class="card-body">
                                <?php echo $__env->make('comment.comment', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                <h5 class="card-title m-0"><?php echo e($comment->user->name); ?></h5>
                                <p class="card-text p-0 m-0"><small class="text-muted"><?php echo e($comment->updated_at->diffForHumans()); ?></small></p>
                                <p class="card-text"><?php echo e($comment->comment); ?></p>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <!-- end feedback layout -->
    <div class="bg-light p-4 container bg-white">
        <span class="p-4">
            <?php echo e($feedbacks->links()); ?>

        </span>
    </div>

    <?php if($product->status_id ==1): ?>
    <!-- inactive -->
    <div class="container-fluid bg-light p-3 mt-4">
        <div class="container shadow py-3">
            <div class="alert alert-light fs-3" role="alert">
                Product owner disbled to accept feedback!
            </div>
        </div>
    </div>
    <?php else: ?>
    <!-- active -->
    <?php echo $__env->make('feedback.add-feedback', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>
 <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?><?php /**PATH C:\Users\Paul\Desktop\feedback-app-round3\resources\views/feedback/feedback.blade.php ENDPATH**/ ?>