<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="overflow-hidden shadow-xl sm:rounded-lg">
                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="card mb-3 p-4">
                    <?php if($product->user_id == Auth::user()->id): ?>
                    <div class="container d-flex justify-content-end px-3 mt-4">
                        <div class="dropdown">

                            <i class="fas fa-ellipsis-h pt-2 " type="button" id="dropdownMenuButton1" data-bs-toggle="dropdown" aria-expanded="false"></i>

                            <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton1">
                                <li>
                                    <p class="dropdown-item" data-bs-toggle="modal" data-bs-toggle="modal" data-bs-target="#<?php echo e(str_replace(" ", "",$product->name).$product->id); ?>">Edit</p>
                                </li>

                                <form action="/products/<?php echo e($product->id); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <li>
                                        <button class="dropdown-item">
                                            Delete
                                        </button>
                                    </li>
                                </form>
                            </ul>
                            <!-- Edit Modal -->
                            <div class="modal fade" id="<?php echo e(str_replace(" ", "",$product->name).$product->id); ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                <div class="modal-dialog modal-lg">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <h5 class="modal-title text-dark" id="exampleModalLabel">Edit Product</h5>
                                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                        </div>
                                        <form action="/products/<?php echo e($product->id); ?>" method="POST" enctype="multipart/form-data">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('PUT'); ?>
                                            <div class="modal-body">
                                                <div class="mb-3">
                                                    <label for="exampleFormControlInput1" class="form-label">Product Name</label>
                                                    <input type="text" class="form-control capitalized" name="name" required value="<?php echo e($product->name); ?>">
                                                </div>
                                                <div class="mb-3">
                                                    <label for="exampleFormControlInput1" class="form-label">Description</label>
                                                    <textarea rows="6" class="form-control capitalized" name="description" required value=><?php echo e($product->description); ?></textarea>
                                                </div>
                                                <div class="mb-3">
                                                    <label for="exampleFormControlInput1" class="form-label">Released Date</label>
                                                    <input type="date" class="form-control capitalized" name="released_date" required value="<?php echo e($product->released_date); ?>">
                                                </div>
                                                <div class="mb-3">
                                                    <label for="exampleFormControlInput1" class="form-label">Image</label>
                                                    <input type="file" accept="image/*" name="file" class="form-control edit-file" />
                                                </div>
                                            </div>
                                            <div class="modal-footer">
                                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                                <button type="submit" class="btn btn-primary">Save Product</button>
                                            </div>

                                        </form>

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php endif; ?>
                    <div class="row g-0">
                        <div class="col-md-4">
                            <img src="<?php echo e(asset('images/products')); ?>/<?php echo e($product->image); ?>" class="img-fluid rounded-start" alt="...">
                        </div>
                        <div class="col-md-8 d-flex flex-column justify-content-around">
                            <div class="card-body">
                                <div class="col-md-12 mb-2 d-flex justify-content-start">
                                    <div class="d-flex col-1 flex-column justify-content-start">
                                        <img src="<?php echo e(asset('images/company')); ?>/<?php echo e($product->company->image); ?>" alt="<?php echo e($product->company->image); ?>" class=" border-0 rounded-circle col-10" alt="...">
                                    </div>
                                    <div class="d-flex flex-column justify-content-center col-11">
                                        <a href="/companies/<?php echo e($product->company_id); ?>">
                                            <h6 class="card-title text-capitalize mt-2"><?php echo e($product->company->name); ?></h6>
                                        </a>
                                    </div>
                                </div>
                                <h5 class="card-title "><?php echo e($product->name); ?></h5>


                                <small class="card-text"><b>Released: </b> <?php echo e(\Carbon\Carbon::parse($product->released_date)->format('d/m/y')); ?></small>
                                <div class="mt-1">
                                    <b>Description</b><br>
                                    <p class="card-text"><?php echo nl2br($product->description); ?></p>
                                </div>
                                <p class="card-text"><small class="text-muted"><?php echo e($product->updated_at->diffForHumans()); ?></small></p>
                            </div>
                            <div class="d-flex justify-content-end">
                                <div>
                                    <?php if($product->user_id == Auth::user()->id): ?>
                                    <!-- 1 of inactive -->
                                    <?php if($product->status->id == 1): ?>
                                    <small class="card-text bg-danger p-1 rounded" id="status" data-bs-toggle="dropdown" aria-expanded="false">
                                        <button>
                                            <?php echo e($product->status->name); ?>

                                        </button>
                                    </small>
                                    <?php else: ?>
                                    <small class="card-text bg-success p-1 rounded" id="status" data-bs-toggle="dropdown" aria-expanded="false">
                                        <button>
                                            <?php echo e($product->status->name); ?>

                                        </button>
                                    </small>
                                    <?php endif; ?>
                                    <ul class="dropdown-menu" aria-labelledby="status">
                                        <?php if($product->status->id == 1): ?>
                                        <form action="/products/<?php echo e($product->id); ?>" method="POST">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('PUT'); ?>
                                            <li>
                                                <button class="dropdown-item">
                                                    Activate
                                                </button>
                                            </li>
                                        </form>
                                        <?php else: ?>
                                        <form action="/products/<?php echo e($product->id); ?>" method="POST">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('PUT'); ?>
                                            <li>
                                                <button class="dropdown-item">
                                                    Inactivate
                                                </button>
                                            </li>
                                        </form> <?php endif; ?>
                                    </ul>
                                    <?php endif; ?>
                                    <small class="card-text bg-light shadow p-1 rounded ml-1 mr-3">
                                        <a href="/products/<?php echo e($product->id); ?>" class="text-decoration-none text-dark bg-gray-150">
                                            Feedbacks
                                        </a>
                                    </small>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </div>
        </div>
    </div>
 <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?><?php /**PATH C:\Users\Paul\Desktop\feedback-app-round3\resources\views/dashboard.blade.php ENDPATH**/ ?>